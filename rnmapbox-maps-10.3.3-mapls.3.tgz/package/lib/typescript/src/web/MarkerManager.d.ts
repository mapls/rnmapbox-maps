import type { Map } from 'mapbox-gl';
export type MarkerAnchor = 'center' | 'top' | 'bottom' | 'left' | 'right' | 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
export declare class ManagedMarker {
    _manager: MarkerManager | null;
    _element: HTMLElement;
    _lngLat: [number, number];
    _anchorTranslate: string;
    _lastX: number | null;
    _lastY: number | null;
    constructor(manager: MarkerManager, element: HTMLElement, lngLat: [number, number], anchor: MarkerAnchor);
    getElement(): HTMLElement;
    getLngLat(): {
        lng: number;
        lat: number;
    };
    setLngLat(lngLat: [number, number]): this;
    remove(): void;
}
/**
 * Positions plain DOM marker elements over the map with a single per-frame
 * pass. Unlike one mapboxgl.Marker per pin (each with its own 'move'
 * listener, projection and DOM task), all markers share one listener and one
 * batched loop, which keeps panning smooth with many pins (notably on
 * Firefox). Intentionally skips mapbox Marker features the app never uses on
 * web: occlusion opacity, world-copy wrapping, dragging, pitch/rotation
 * alignment (the web app runs a 2D camera).
 */
export declare class MarkerManager {
    _map: Map | null;
    _markers: Set<ManagedMarker>;
    _onMove: () => void;
    constructor(map: Map);
    add(element: HTMLElement, lngLat: [number, number], anchor: MarkerAnchor): ManagedMarker;
    remove(marker: ManagedMarker): void;
    reposition(marker: ManagedMarker): void;
    _repositionAll(): void;
    destroy(): void;
}
export default MarkerManager;
//# sourceMappingURL=MarkerManager.d.ts.map