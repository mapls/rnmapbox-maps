import React from 'react';
import type { Map } from 'mapbox-gl';
import type { MarkerManager } from './MarkerManager';
declare const MapContext: React.Context<{
    map?: Map;
    markerManager?: MarkerManager;
}>;
export default MapContext;
//# sourceMappingURL=MapContext.d.ts.map