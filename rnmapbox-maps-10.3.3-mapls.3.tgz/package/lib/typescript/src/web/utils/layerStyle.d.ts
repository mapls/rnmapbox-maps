import type { Map } from 'mapbox-gl';
export type WebLayerType = 'line' | 'symbol' | 'circle';
export type SplitStyle = {
    layout: Record<string, unknown>;
    paint: Record<string, unknown>;
};
export declare const camelToKebab: (key: string) => string;
/**
 * Splits a camelCase rnmapbox style object into mapbox-gl layout and paint
 * objects with kebab-cased keys. `*Transition` keys whose base property is a
 * paint key stay paint (mapbox-gl accepts `<prop>-transition` via
 * setPaintProperty and in layer definitions).
 */
export declare const splitLayerStyle: (type: WebLayerType, style: Record<string, unknown> | undefined) => SplitStyle;
export declare const styleValueEquals: (a: unknown, b: unknown) => boolean;
/**
 * Applies only the changed keys between two split styles. This is the per-frame
 * hot path for animated style props (e.g. a marching text-offset): a single
 * changed key results in a single setLayoutProperty/setPaintProperty call.
 */
export declare const diffApplyStyle: (map: Map, layerId: string, prev: SplitStyle | null, next: SplitStyle) => void;
//# sourceMappingURL=layerStyle.d.ts.map