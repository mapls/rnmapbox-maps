import 'mapbox-gl/dist/mapbox-gl.css';
import Camera from './components/Camera';
import CircleLayer from './components/CircleLayer';
import LineLayer from './components/LineLayer';
import MapView from './components/MapView';
import MarkerView from './components/MarkerView';
import ShapeSource from './components/ShapeSource';
import SymbolLayer from './components/SymbolLayer';
import Logger from './utils/Logger';
declare const Mapbox: {
    Camera: typeof Camera;
    CircleLayer: typeof CircleLayer;
    LineLayer: typeof LineLayer;
    MapView: typeof MapView;
    Logger: typeof Logger;
    MarkerView: import("react").NamedExoticComponent<{
        coordinate: [number, number];
        anchor?: {
            x: number;
            y: number;
        };
        children?: import("react").ReactElement;
        style?: import("react-native").ViewStyle;
        className?: string;
    } & import("react").RefAttributes<import("./components/MarkerView").MarkerViewRef>>;
    ShapeSource: typeof ShapeSource;
    SymbolLayer: typeof SymbolLayer;
    LineJoin: {
        Bevel: string;
        Round: string;
        Miter: string;
    };
    StyleURL: {
        Street: string;
        Satellite: string;
    };
    setAccessToken: (token: string) => void;
};
export { Camera, CircleLayer, LineLayer, Logger, MapView, MarkerView, ShapeSource, SymbolLayer, };
export * from './MapboxModule';
export default Mapbox;
//# sourceMappingURL=index.d.ts.map