import type { LineLayerStyleProps } from '../../utils/MapboxStyles';
import { type WebLayerProps } from './useWebLayer';
export type LineLayerProps = Omit<WebLayerProps, 'style'> & {
    style?: LineLayerStyleProps;
};
/** Web LineLayer: renders a mapbox-gl line layer from the enclosing ShapeSource. */
declare function LineLayer(props: LineLayerProps): null;
export default LineLayer;
//# sourceMappingURL=LineLayer.d.ts.map