import React from 'react';
import type { Position } from '../../types/Position';
import { MarkerManager } from '../MarkerManager';
import * as RNMapView from '../../components/MapView';
/**
 * MapView backed by Mapbox GL KS
 */
type styleURLProps = {
    styleURL: string;
};
interface LayerColorState {
    layerId: string;
    property: string;
    originalValue: any;
}
declare class MapView extends React.Component<RNMapView.default & {
    styleURL: string;
    children: React.JSX.Element;
    onPress: (e: GeoJSON.Feature) => void;
    onCameraChanged: (e: RNMapView.MapState) => void;
    onMapIdle: (e: RNMapView.MapState) => void;
    onWillStartLoadingMap?: () => void;
    onDidFinishLoadingMap?: () => void;
    _setStyleURL: (props: styleURLProps) => void;
    setMonochrome: (enabled: boolean) => void;
    recoverOnContextLost?: boolean;
} & {
    map?: mapboxgl.Map | null;
}> {
    state: {
        map: null;
    };
    mapContainer: HTMLElement | null;
    map: mapboxgl.Map | null;
    originalLandColors: LayerColorState[];
    colorOperationInProgress: boolean;
    _rafId: number | null;
    _pendingMove: boolean;
    _onVisibilityChange: (() => void) | null;
    _moveState: RNMapView.MapState;
    markerManager: MarkerManager | null;
    _contextValue: {
        map?: mapboxgl.Map;
        markerManager?: MarkerManager;
    };
    _contextLost: boolean;
    _graceTimer: number | null;
    _retryTimer: number | null;
    _recreateAttempts: number;
    _pendingRecreateOpts: Partial<mapboxgl.MapOptions> | null;
    _lastLandColor: string | null;
    static RECOVERY_GRACE_MS: number;
    static RECOVERY_MAX_ATTEMPTS: number;
    static RECOVERY_BACKOFF_MS: number;
    componentDidMount(): void;
    _createMap: (cameraOpts?: Partial<mapboxgl.MapOptions>) => void;
    _isContextLost(): boolean;
    _scheduleRecovery: () => void;
    _recoverIfNeeded: () => void;
    _tryCreateMap: () => void;
    _handleVisibilityChange: () => void;
    _clearTimers: () => void;
    componentWillUnmount(): void;
    _setStyleURL: (props: styleURLProps) => void;
    colorLand: (baseColor: string) => void;
    resetLandColors: () => void;
    setLandColor: (color: string) => void;
    resetLandColor: () => void;
    setMonochrome: (enabled: boolean) => void;
    applyMonochromeFilter(enable: boolean): void;
    handleMapPress(e: GeoJSON.Feature<GeoJSON.Point>): void;
    handleCameraChanged(e: RNMapView.MapState): void;
    handleMapOnIdle(e: RNMapView.MapState): void;
    getZoom(): number | undefined;
    getPointInView(coordinate: Position): Promise<Position>;
    render(): import("react/jsx-runtime").JSX.Element;
}
export default MapView;
//# sourceMappingURL=MapView.d.ts.map