import { Component, type ContextType } from 'react';
import { type CameraProps, type CameraStop, type CameraRef } from '../../components/Camera';
import { type Position } from '../../types/Position';
import MapContext from '../MapContext';
declare class Camera extends Component<Pick<CameraProps, 'centerCoordinate' | 'zoomLevel' | 'minZoomLevel' | 'maxZoomLevel'>> implements Omit<CameraRef, 'setCamera' | 'moveBy' | 'scaleBy'> {
    context: ContextType<typeof MapContext>;
    static contextType: import("react").Context<{
        map?: import("mapbox-gl").Map;
        markerManager?: import("../MarkerManager").MarkerManager;
    }>;
    static UserTrackingModes: never[];
    componentDidMount(): void;
    fitBounds(northEastCoordinates: Position, southWestCoordinates: Position, padding?: number | number[], animationDuration?: number): void;
    flyTo(centerCoordinate: Position, animationDuration?: number): void;
    moveTo(centerCoordinate: Position, animationDuration?: number): void;
    zoomTo(zoomLevel: number, animationDuration?: number): void;
    setCamera(props: CameraStop): void;
    render(): import("react/jsx-runtime").JSX.Element;
}
export { Camera };
export default Camera;
//# sourceMappingURL=Camera.d.ts.map