import type { CircleLayerStyleProps } from '../../utils/MapboxStyles';
import { type WebLayerProps } from './useWebLayer';
export type CircleLayerProps = Omit<WebLayerProps, 'style'> & {
    style?: CircleLayerStyleProps;
};
/** Web CircleLayer: renders a mapbox-gl circle layer from the enclosing ShapeSource. */
declare function CircleLayer(props: CircleLayerProps): null;
export default CircleLayer;
//# sourceMappingURL=CircleLayer.d.ts.map