export = config;
/** @type {import('jest').Config} */
declare const config: import("jest").Config;
//# sourceMappingURL=jest.config.d.ts.map